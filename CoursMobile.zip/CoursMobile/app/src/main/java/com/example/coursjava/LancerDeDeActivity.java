package com.example.coursjava;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ThreadLocalRandom;

public class LancerDeDeActivity extends AppCompatActivity {

    private Button lancerDe;
    private TextView texteLancer;
    private ImageView imageDe;
    private ImageView imageDeTurn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lancer_de_de);

        lancerDe = (Button) findViewById(R.id.lancerButton);
        texteLancer = (TextView) findViewById(R.id.texteLancer);
        imageDe = (ImageView) findViewById(R.id.imageDe);
        imageDeTurn = (ImageView) findViewById(R.id.imageTurn);

        lancerDe.setOnClickListener(new View.OnClickListener() {

            public void turnDe(int time) {
                new android.os.Handler().postDelayed(
                        new Runnable() {

                            @Override
                            public void run() {
                                int test = (int) (Math.random() * (6 - 1 + 1) + 1);

                                if (test == 1) {
                                    imageDeTurn.setImageResource(R.drawable.d1);
                                } else if (test == 2) {
                                    imageDeTurn.setImageResource(R.drawable.d2);
                                } else if (test == 3) {
                                    imageDeTurn.setImageResource(R.drawable.d3);
                                } else if (test == 4) {
                                    imageDeTurn.setImageResource(R.drawable.d4);
                                } else if (test == 5) {
                                    imageDeTurn.setImageResource(R.drawable.d5);
                                } else if (test == 6) {
                                    imageDeTurn.setImageResource(R.drawable.d6);
                                }
                            }
                        }, time);
            }

            @Override
            public void onClick(View view) {
                int b = (int) (Math.random() * (6 - 1 + 1) + 1);
                String s = String.valueOf(b);
                texteLancer.setText(s);

                if (b == 1) {
                    imageDe.setImageResource(R.drawable.d1);
                } else if (b == 2) {
                    imageDe.setImageResource(R.drawable.d2);
                } else if (b == 3) {
                    imageDe.setImageResource(R.drawable.d3);
                } else if (b == 4) {
                    imageDe.setImageResource(R.drawable.d4);
                } else if (b == 5) {
                    imageDe.setImageResource(R.drawable.d5);
                } else if (b == 6) {
                    imageDe.setImageResource(R.drawable.d6);
                }

                for(int i = 0; i < 10; i++) {
                    turnDe(i*300);

                }






            }
        });


    }
}